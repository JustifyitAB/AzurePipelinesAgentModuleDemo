# VstsAgentWin

Powershell module using for install, configure, or uninstall self-hosted Azure Pipelines agent.

## Install Chocolatey, .Net, Powershell if needed

````powershell
$User = [Security.Principal.WindowsIdentity]::GetCurrent();
    if (-not (New-Object Security.Principal.WindowsPrincipal $User).IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)) {
    throw "You must run as Administrator"
}

if (-not ($env:ChocolateyInstall)) {
    if ((Get-ExecutionPolicy) -eq "Restricted") {
        Set-ExecutionPolicy Bypass -Scope Process -Force
    }

    [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072 # TLS 1.2
    Invoke-Expression ((New-Object System.Net.WebClient).DownloadString("https://chocolatey.org/install.ps1"))
    if ($LASTEXITCODE) {
        throw "Chocolatey installation was NOT successfully"
    }
}

choco feature enable -n allowGlobalConfirmation
choco upgrade dotnet-sdk # .NET 5 SDK
choco upgrade powershell-core # Powershell Core
````

## Install or Update module and register PSRepository PSSEK if needed

````powershell
if (-not (Get-PSRepository | Where-Object Name -eq PSSEK)) {
    if (-not(Get-PackageProvider | Where-Object Name -eq NuGet)) {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Install-PackageProvider -Name NuGet -Force
    }

    if (-not (Get-Module -ListAvailable PowerShellGet | Where-Object Version -gt 1.0.0.1)) {
        Install-Module -Name PowerShellGet -Force
    }
    
    try {
        $Location = "https://azuredevops.sek.se/SEKCollection/_packaging/PSSEK/nuget/v2"        
        $PSRepo = @{
            Name               = "PSSEK"
            SourceLocation     = $Location
            PublishLocation    = $Location
            InstallationPolicy = "Trusted"
        }
        Register-PSRepository @PSRepo
    }
    catch {
        throw "The user " + $Credential.UserName + " has no access to Azure DevOps"
    }
}

if (-not (Get-Module -ListAvailable | Where-Object Name -eq "VstsAgentWin")) {
    Install-Module -Name VstsAgentWin -Repository PSSEK
}
else {
    Update-Module -Name VstsAgentWin -Force
}
````

## Commands

| Name | Synopsis |
| - | - |
| [Get-SslCACertsContent](docs\Get-SslCACertsContent.md) | Get self-signed root ca certificate and intermediate ca certificate content |
| [Install-VstsAgentWin](docs\Install-VstsAgentWin.md) | Download and install Self-hosted Azure Pipelines agent on this machine |
| [Save-VstsAgentPackage](docs\Save-VstsAgentPackage.md) | Download and unzip into agent path azure-pipelines-agent from internal nuget feed |
| [Uninstall-VstsAgentWin](docs\Uninstall-VstsAgentWin.md) | Uninstall Self-hosted Azure Pipelines agent on this machine |
