---
external help file: VstsAgentWin-help.xml
Module Name: VstsAgentWin
online version:
schema: 2.0.0
---

# Get-SslCACertsContent

## SYNOPSIS
Get self-signed root ca certificate and intermediate ca certificate content

## SYNTAX

```
Get-SslCACertsContent [<CommonParameters>]
```

## DESCRIPTION
Get self-signed root ca certificate and intermediate ca certificate content

## EXAMPLES

### EXAMPLE 1
```
Get-SslCACertsContent | Set-Content ca.pem
```

## PARAMETERS

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

### No input
## OUTPUTS

### Content of root ca and issuing content
## NOTES

## RELATED LINKS
