# Functions
. $PSScriptRoot\Get-SslCACertsContent.ps1
. $PSScriptRoot\Install-VstsAgentWin.ps1
. $PSScriptRoot\Save-VstsAgentPackage.ps1
. $PSScriptRoot\Uninstall-VstsAgentWin.ps1

# Variables
$variables = (Get-Content $PSScriptRoot\variables.json | ConvertFrom-Json).psobject.properties
$variables | ForEach-Object {
    New-Variable -Name $_.Name -Value $_.Value -Description "Variables from VstsAgentWin module" -Option ReadOnly -Force
}

Export-ModuleMember -Function @(
    "Get-SslCACertsContent",
    "Install-VstsAgentWin",
    "Save-VstsAgentPackage",
    "Uninstall-VstsAgentWin"
) -Variable $variables.Name
