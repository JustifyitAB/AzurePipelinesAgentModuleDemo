. $PSScriptRoot\Test-RunAsAdmin.ps1
. $PSScriptRoot\Invoke-VstsAgentConfig.ps1
function Uninstall-VstsAgentWin {
    <#
    .SYNOPSIS
        Uninstall Self-hosted Azure Pipelines agent on this machine
    .DESCRIPTION
        You MUST run this function as Administrator, because you are going to create a windows service.
        If you like to save agent folder after uninstall i Azure DevOps use DeleteFolder flag.
    .EXAMPLE
        Uninstall-VstsAgentWin -AgentPath "E:\azagent\A1"
    .EXAMPLE
        "E:\azagent\A1","E:\azagent\A2" | Uninstall-VstsAgentWin
    .EXAMPLE
        $cred = Get-Credential -UserName $env:USERNAME@$env:USERDNSDOMAIN
        Uninstall-VstsAgentWin -AgentPath "E:\azagent\A1" -Auth negotiate -Credential $cred
    .EXAMPLE
        # Uninstall all agent on server
        (Get-ChildItem E:\azagent).FullName | Uninstall-VstsAgentWin -DeleteFolder
    .EXAMPLE
        # Reconfigure all agents in the folder
        (Get-ChildItem E:\azagent).FullName | Uninstall-VstsAgentWin | Install-VstsAgentWin -Pool MyPool -CapabilityTags CoolTag1,CoolTag2
    .OUTPUTS
        None, [System.Management.Automation.PathInfo] Path to agent folder if using DeleteFolder
    #>
    [CmdletBinding()]
    param (
        # Path to agent home folder.
        [Parameter(Mandatory, ValueFromPipeline)]
        [ValidateScript( { Test-Path $_/config.cmd })]
        [string]$AgentPath,

        # Authentication type: personal access token (pat), windows default credentials (integrated) or PSCredential
        # If using pat you MUST specified your pat-token in varable $env:VSTS_AGENT_INPUT_token before you call.
        # Note:
        # Create a personal access token with name 'VstsAgent' for 'All accessible organizations' with Scopes:
        # Agent Pools (Read & mangage); Environment (Read & manage); Deployment Groups (Read & manage) 
        [ValidateSet("pat", "integrated", "negotiate")]
        [String]$Auth = "integrated",

        # Use when auth is negotiate
        [PSCredential] $Credential,

        # Delete agent folder after uninstall i Azure DevOps
        [switch]$DeleteFolder
    )
    begin {
        if ($Auth -eq "pat" -and $null -eq $env:VSTS_AGENT_INPUT_token) {
            throw "You must specified your pat-token in varable `$env:VSTS_AGENT_INPUT_token before you call"
        }
        if ($Auth -eq "negotiate" -and $null -eq $Credential) {
            throw "You must specified -Credential before you call"
        }
    }
    process {
        $AgentPath = Resolve-Path $AgentPath # Braces and belt. Fix to absolut path

        # Check if you run as admin
        if (-not (Test-RunAsAdmin)) {
            throw "You MUST run this functions as Administrator"
        }

        # Delete agent from server and delete windows service
        $ConfigureArgs = @("remove", "--auth '$Auth'")

        if ($Auth -eq "negotiate") {
            [System.Net.NetworkCredential] $NetworkCredential = New-Object -TypeName System.Net.NetworkCredential -ArgumentList $Credential.UserName, $Credential.Password
            $env:VSTS_AGENT_INPUT_userName = $NetworkCredential.UserName
            $env:VSTS_AGENT_INPUT_password = $NetworkCredential.Password
        }
         
        if (-not (Invoke-VstsAgentConfig -AgentPath $AgentPath -ConfigureArgs $ConfigureArgs)) {
            throw "The installation failed"
        }

        # Delete agent folder or only delete .capabilities file 
        if ($DeleteFolder) {
            Start-Sleep -Seconds 10 # Wait for windows service to delete 
            Remove-Item $AgentPath -Recurse
            # If folder is empty then delete parent folder
            $parentPath = Split-Path $AgentPath
            if (-not (Get-ChildItem $parentPath)) {
                Remove-Item $parentPath
            }
        }
        else {
            if (Test-Path $AgentPath/.capabilities) {
                Remove-Item $AgentPath/.capabilities
            }
            $AgentPath # Return path for piping
        }

        Write-Host "The uninstallation was successful :-)"
    }
}
