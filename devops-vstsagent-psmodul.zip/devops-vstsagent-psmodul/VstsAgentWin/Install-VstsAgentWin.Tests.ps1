BeforeAll {
    Import-Module -Name $PSScriptRoot\VstsAgentWin -Scope Local
    . $PSScriptRoot\Install-VstsAgentWin.ps1
    . $PSScriptRoot\Mock.Tests.ps1
    Mock Import-AzDoCertificates { }
    Mock Set-Content { }
    Mock Save-VstsAgentPackage {
        param ($AgentBasePath, $AgentPath)
        New-Item -Path $AgentPath -Name config.cmd -Type File
    }
}

Describe "Install-VstsAgentWin" {
    BeforeEach {
        $script:ActualConfigureArgs = @()
        $AgentBasePath = New-Item -Path . -Name (New-Guid) -Type Directory
        Mock Get-AgentBasePath { $AgentBasePath }
    }

    AfterEach {
        Remove-Item $AgentBasePath -Recurse
    }

    It "Should use AgentPath" {
        $AgentBasePathLocal = New-Item -Path . -Name (New-Guid) -Type Directory
        $AgentPathLocal = New-Item -Path $AgentBasePathLocal -Name A10 -Type Directory
        
        Install-VstsAgentWin -AgentPath $AgentPathLocal | Out-Null
        $script:ActualConfigureArgs | Should -Contain "--agent '$env:COMPUTERNAME-10'"
        Remove-Item $AgentBasePathLocal -Recurse
    }

    It "Should throw config.cmd is missing" {
        Mock Save-VstsAgentPackage {
            param ($AgentBasePath, $AgentPath)
            New-Item -Path $AgentPath -Name no-config.cmd -Type File
        }

        { Install-VstsAgentWin } | Should -Throw "File */config.cmd is missing"
    }

    It "Should use pat-token" {
        $env:VSTS_AGENT_INPUT_token = "kjfkgjf"
        Install-VstsAgentWin -Auth pat
        $script:ActualConfigureArgs | Should -Contain "--auth 'pat'"
    }

    It "Should return AgentPath" {
        $AgentBasePath = Get-AgentBasePath
        $sut = Install-VstsAgentWin
        $sut.AgentPath | Should -Be "$AgentBasePath\A1"
    }

    It "Should return default ServiceAccountCredential" {
        $sut = Install-VstsAgentWin
        $sut.ServiceAccountCredential.UserName | Should -Be $VstsAgentWinWindowsLogonAccount
        $sut.ServiceAccountCredential.Password.Length | Should -Be 0
    }

    It "Should return local ServiceAccountCredential" {
        $sut = Install-VstsAgentWin -WindowsLogonAccount "NT AUTHORITY\SYSTEM"
        $sut.ServiceAccountCredential.UserName | Should -Be "NT AUTHORITY\SYSTEM"
        $sut.ServiceAccountCredential.Password.Length | Should -Be 0
    }

    It "Should return AD user as ServiceAccountCredential" {
        [PSCredential] $expected = New-Object -TypeName PSCredential -ArgumentList "svc-azdo-computer1@sek.se", (ConvertTo-SecureString "xxx" -AsPlainText -Force)
        
        $sut = Install-VstsAgentWin -WindowsLogonAccount $expected.UserName -WindowsLogonPassword $expected.Password

        $sut.ServiceAccountCredential.UserName | Should -Be $expected.UserName
        $sut.ServiceAccountCredential.Password | Should -Be $expected.Password
    }

    It "Should throw you must specified your pat-token" {
        $env:VSTS_AGENT_INPUT_token = $null
        { Install-VstsAgentWin -Auth pat } | Should -Throw "You must specified your pat-token in varable*"
    }

    It "Should throw avoid using more than 10 agents" {
        $AgentBasePathLocal = New-Item -Path . -Name (New-Guid) -Type Directory
        1..10 | ForEach-Object { New-Item -Path $AgentBasePathLocal -Name A$_ -Type Directory | Out-Null }
        Mock Get-AgentBasePath { $AgentBasePathLocal }

        (Get-ChildItem $AgentBasePathLocal).Length | Should -Be 10
        { Install-VstsAgentWin } | Should -Throw "Avoid using more than 10 agents*"
        Remove-Item $AgentBasePathLocal -Recurse
    }

    It "Should contains --agent" {
        Install-VstsAgentWin | Out-Null
        $script:ActualConfigureArgs | Should -Contain "--agent '$env:COMPUTERNAME-1'"
    }

    It "Should contains --pool" {
        Install-VstsAgentWin -Pool MyPool | Out-Null
        $script:ActualConfigureArgs | Should -Contain "--pool 'MyPool'"
    }

    It "Should contains --runAsService" {
        Install-VstsAgentWin | Out-Null
        $script:ActualConfigureArgs | Should -Contain "--runAsService"
    }

    It "Should contains --projectname SEK" {
        Install-VstsAgentWin -DeploymentGroupName AHS-Dev | Out-Null
        $script:ActualConfigureArgs | Should -Contain "--projectname 'SEK'"
        $script:ActualConfigureArgs | Should -Contain "--deploymentgroupname 'AHS-Dev'"
    }

    It "Should contains --sslcacert" {
        $AgentBasePathLocal = New-Item -Path . -Name (New-Guid) -Type Directory
        $AgentPathLocal = New-Item -Path $AgentBasePathLocal -Name A1 -Type Directory

        Install-VstsAgentWin -AgentPath $AgentPathLocal | Out-Null
        $script:ActualConfigureArgs | Should -Contain "--sslcacert '$AgentPathLocal\ca.pem'"
        Remove-Item $AgentBasePathLocal -Recurse
    }

    It "Should contains --deploymentpoolname" {
        Install-VstsAgentWin -DeploymentPoolName "MyPool" | Out-Null
        $script:ActualConfigureArgs | Should -Contain "--deploymentpool"
        $script:ActualConfigureArgs | Should -Contain "--deploymentpoolname 'MyPool'"
    }

    It "Should contains --environment" {
        Install-VstsAgentWin -EnvironmentName Lek | Out-Null
        $script:ActualConfigureArgs | Should -Contain "--environment"
        $script:ActualConfigureArgs | Should -Contain "--environmentname 'Lek'"
    }

    It "Should contains --addvirtualmachineresourcetags" {
        Install-VstsAgentWin -EnvironmentName Lek -EnvironmentVMResourceTags PRESS, XOR | Out-Null
        $script:ActualConfigureArgs | Should -Contain "--addvirtualmachineresourcetags"
        $script:ActualConfigureArgs | Should -Contain "--virtualmachineresourcetags 'PRESS,XOR'"
    }

    It "Should contains --adddeploymentgrouptags" {
        Install-VstsAgentWin -DeploymentGroupName X -DeploymentGroupTags AAA, BBB | Out-Null
        $script:ActualConfigureArgs | Should -Contain "--adddeploymentgrouptags"
        $script:ActualConfigureArgs | Should -Contain "--deploymentgrouptags 'AAA,BBB'"
    }


    It "Should contains --windowslogonaccount ad users" {
        $pass = ConvertTo-SecureString "p" -AsPlainText
        Install-VstsAgentWin -DeploymentPoolName "MyPool" -WindowsLogonAccount hej -WindowsLogonPassword $pass | Out-Null

        $script:ActualConfigureArgs | Should -Contain "--windowslogonaccount 'hej'"
        $script:ActualConfigureArgs | Should -Not -Contain "--windowslogonpassword 'p'"
    }

    It "Should set VSTS_AGENT_INPUT_password" {
        $User = "$env:USERNAME@$env:USERDOMAIN"
        $Pass = New-Guid
        $PassSec = ConvertTo-SecureString $Pass -AsPlainText -Force
        [PSCredential] $Credential = New-Object -TypeName PSCredential -ArgumentList $User, $PassSec

        Install-VstsAgentWin -Auth negotiate -Credential $Credential | Out-Null

        $script:ActualConfigureArgs | Should -Contain "--auth 'negotiate'"
        $env:VSTS_AGENT_INPUT_userName  | Should -Be $User
        $env:VSTS_AGENT_INPUT_password  | Should -Be $Pass
    }

    It "Should create capabilities" {
        Mock Add-Content {
            param($Path, $Value)
            if ($Value) {
                $Value.Split("=").Length | Should -Be 2
            }
        }
        $AgentBasePathLocal = New-Item -Path . -Name (New-Guid) -Type Directory
        $AgentPathLocal = New-Item -Path $AgentBasePathLocal -Name A1 -Type Directory

        Install-VstsAgentWin -AgentPath $AgentPathLocal -CapabilityTags Tag1, Tag2=hej | Out-Null
        
        Assert-MockCalled Add-Content -Times 2
        Remove-Item $AgentBasePathLocal -Recurse
    }

    It "Should throw missing password" {
        { Install-VstsAgentWin -WindowsLogonAccount xxx } |
        Should -Throw "You must specified WindowsLogonPassword as SecureString"
    }

    It "Should throw missing cred" {
        { Install-VstsAgentWin -Auth negotiate } |
        Should -Throw "You must specified -Credential before you call"
    }
}
