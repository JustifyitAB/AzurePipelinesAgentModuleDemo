BeforeAll {
    Import-Module -Name $PSScriptRoot\VstsAgentWin -Scope Local
    . $PSScriptRoot\Save-VstsAgentPackage.ps1
}

Describe "Save-VstsAgentPackage" {
    BeforeEach {
        $script:AgentBasePath = New-Item -Path . -Name (New-Guid) -Type Directory
        $script:AgentPath = New-Item -Path $AgentBasePath -Name A1 -Type Directory
        $script:TempPath = New-Item -Path $AgentBasePath -Name agent -Type Directory
    }

    AfterEach {
        Remove-Item $script:AgentBasePath -Recurse
    }

    It "Check variables" {
        $VstsAgentWinRuntime.Length | Should -BeGreaterThan 0
        $VstsAgentWinAgentVersion.Length | Should -BeGreaterThan 0
        $VstsAgentWinWindowsLogonAccount.Length | Should -BeGreaterThan 0
    }

    It "Package from Azure DevOps" {

        Mock Save-Package {
            $CompressZip = @{
                Path            = New-Item -Path $AgentBasePath -Name config.cmd -Type File
                DestinationPath = "$AgentBasePath/agent/vsts-agent-$VstsAgentWinRuntime-$VstsAgentWinAgentVersion.zip"
            }
            Compress-Archive @CompressZip
            Remove-Item $CompressZip.Path

            $CompressNupkg = @{
                Path            = $CompressZip.DestinationPath
                DestinationPath = "$AgentBasePath/agent/azure-pipelines-agent.$VstsAgentWinAgentVersion.nupkg"
            }
            Compress-Archive @CompressNupkg
            Remove-Item $CompressNupkg.Path
        }
        
        "$AgentBasePath/vsts-agent-$VstsAgentWinRuntime-$VstsAgentWinAgentVersion.zip" | Should -Not -Exist
        Save-VstsAgentPackage -AgentBasePath $AgentBasePath -AgentPath $AgentPath -TempPath $TempPath
        "$AgentPath/config.cmd" | Should -Exist
        Assert-MockCalled Save-Package -Times 1
    }

    It "Package with internet" {
        Mock Invoke-WebRequest {
            $Compress = @{
                Path            = New-Item -Path $AgentBasePath -Name config.cmd -Type File
                DestinationPath = "$AgentBasePath/vsts-agent-win-x64-2.170.1.zip"
            }
            Compress-Archive @Compress
            $AgentZip = $Compress.DestinationPath
        }
        
        "$AgentBasePath/vsts-agent-win-x64-2.170.1.zip" | Should -Not -Exist
        Save-VstsAgentPackage -AgentBasePath $AgentBasePath -AgentPath $AgentPath -OnlineInstallation
        "$AgentPath/config.cmd" | Should -Exist
        Assert-MockCalled Invoke-WebRequest -Times 1
    }
}