function Get-AgentBasePath {
    $AgentBasePath = "C:/azagent"

    if (Test-Path "E:") {
        $AgentBasePath = "E:/azagent"
    }

    if (-not (Test-Path $AgentBasePath -IsValid)) {
        throw "Cannot using $AgentBasePath as base path. Please manually create a folder and use parameter -AgentPath"
    }
    return $AgentBasePath
}