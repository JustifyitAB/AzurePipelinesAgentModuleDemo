BeforeAll {
    . $PSScriptRoot\Uninstall-VstsAgentWin.ps1
    . $PSScriptRoot\Mock.Tests.ps1
    Mock Remove-Item { }
    Mock Test-Path { $true }
}

Describe "Uninstall-VstsAgentWin" {
    BeforeAll {
        $script:ActualConfigureArgs = @()
    }

    It "Should return AgentPath" {
        Uninstall-VstsAgentWin -AgentPath "path to file" | Should -be "path to file"
    }

    It "Should remove agent folder" {
        Mock Get-ChildItem -Verifiable {}
        Mock Split-Path { param($Path) return $Path }
    
        Uninstall-VstsAgentWin -AgentPath "." -DeleteFolder | Out-Null

        Assert-MockCalled Remove-Item -Times 1
        Assert-MockCalled Get-ChildItem -Times 1
    }

    It "Should set VSTS_AGENT_INPUT_password" {
        $User = "$env:USERNAME@$env:USERDOMAIN"
        $Pass = New-Guid
        $PassSec = ConvertTo-SecureString $Pass -AsPlainText -Force
        [PSCredential] $Credential = New-Object -TypeName PSCredential -ArgumentList $User, $PassSec

        Uninstall-VstsAgentWin -AgentPath "." -Auth negotiate -Credential $Credential | Out-Null

        $script:ActualConfigureArgs | Should -Contain "--auth 'negotiate'"
        $env:VSTS_AGENT_INPUT_userName  | Should -Be $User
        $env:VSTS_AGENT_INPUT_password  | Should -Be $Pass
    }
}
