function Set-EnvironmentVariable {
    [CmdletBinding()]
    param (
        [String]$Key,
        [String]$Val
    )
    process {
        [System.Environment]::SetEnvironmentVariable($Key, $Val, [System.EnvironmentVariableTarget]::Machine)
    }
}