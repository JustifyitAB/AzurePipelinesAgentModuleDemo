function Save-VstsAgentPackage {
    <#
         .SYNOPSIS
            Download and unzip into agent path azure-pipelines-agent from internal nuget feed
         .DESCRIPTION
            Download azure-pipelines-agent from internal nuget feed
         .EXAMPLE
            Save-VstsAgentPackage -AgentBasePath E:/azagent -AgentPath E:/azagent/A1
     #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateScript( { Test-Path $_ })]
        [String] $AgentBasePath,

        [Parameter(Mandatory)]
        [ValidateScript( { Test-Path $_ })]
        [String] $AgentPath,

        [ValidateScript( { Test-Path $_ })]
        [String] $TempPath,

        [Switch] $OnlineInstallation,

        [PSCredential] $Credential
    )
    process {
        if ($OnlineInstallation) {
            $AgentZip = Join-Path -Path $AgentBasePath -ChildPath "vsts-agent-$VstsAgentWinRuntime-$VstsAgentWinAgentVersion.zip"

            if (-not(Test-Path $AgentZip)) {
                [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
                $Param = @{
                    Uri             = "https://vstsagentpackage.azureedge.net/agent/$VstsAgentWinAgentVersion/vsts-agent-$VstsAgentWinRuntime-$VstsAgentWinAgentVersion.zip"
                    Out             = $AgentZip
                    UseBasicParsing = $true
                }
                Invoke-WebRequest @Param
            }
        }
        else {
            # Offline installations
            if (-not($TempPath)) {
                $TempPath = New-Item -Type Directory -Path $AgentBasePath -Name (New-Guid)
            }
    
            if (-not (Get-PackageSource | Where-Object Name -eq $VstsAgentWinNuGetName)) {
                $PackageSource = @{
                    Name         = $VstsAgentWinNuGetName
                    Location     = $VstsAgentWinNuGetSource
                    ProviderName = "NuGet"
                }
                if ($Credential) {
                    $PSRepo.Add("Credential", $Credential)
                }
                Register-PackageSource @PackageSource -Trusted
            }
    
            if (Get-PackageSource | Where-Object Name -eq $VstsAgentWinNuGetName | Find-Package |
                Where-Object Name -eq $VstsAgentWinNuGetPackageName | Where-Object Version -eq $VstsAgentWinAgentVersion) {
                $Package = @{
                    ProviderName    = "NuGet"
                    Name            = $VstsAgentWinNuGetPackageName
                    RequiredVersion = $VstsAgentWinAgentVersion
                    Path            = $TempPath
                }
                if ($Credential) {
                    $Package.Add("Credential", $Credential)
                }
                Save-Package @Package
    
                $nupkg = "$TempPath/*.nupkg"
                if (-not(Test-Path $nupkg)) {
                    throw "Missing nuget package $nupkg"
                }
                Get-ChildItem $nupkg | Rename-Item -NewName { $_.Name -replace ".nupkg", ".zip" }
                $Archive = @{
                    Path            = Resolve-Path "$TempPath/*.zip"
                    DestinationPath = "$TempPath/out"
                }
                Expand-Archive @Archive
            }
            $AgentZip = "$TempPath/out/*.zip"
        }
        
        if (-not(Test-Path $AgentZip)) {
            throw "Agent zip file is missing $AgentZip"
        }

        Expand-Archive -Path ($AgentZip | Resolve-Path) -DestinationPath $AgentPath

        if ($TempPath) {
            Remove-Item $TempPath -Recurse
        }
    }
}