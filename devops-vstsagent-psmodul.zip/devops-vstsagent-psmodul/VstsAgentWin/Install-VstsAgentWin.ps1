. $PSScriptRoot\Test-RunAsAdmin.ps1
. $PSScriptRoot\Save-VstsAgentPackage.ps1
. $PSScriptRoot\Invoke-VstsAgentConfig.ps1
. $PSScriptRoot\Get-SslCACertsContent.ps1
. $PSScriptRoot\Import-AzDoCertificates.ps1
. $PSScriptRoot\Get-AgentBasePath.ps1

function Install-VstsAgentWin {
   <#
         .SYNOPSIS
            Download and install Self-hosted Azure Pipelines agent on this machine
         .DESCRIPTION
            You MUST run this function as Administrator, because you are going to create a windows service.
            You MUST have permissions to register or unregister agent i Azure DevOps. This is a high level permission so only
            adm- user have that permissions. This function use windows default credential for login into Azure DevOps.
            
            The agent can be configurated in 4 different ways:

            - BuildReleasesAgent. New and classic way in Automation. Use as automation agent in yaml file as keyword pool or as classic build agent
            - EnvironmentVMResource. New way in Deployment. Use as deploy agent in release yaml file as keyword environment
            - SharedDeployment. Classic way in Deployment. Use as deploy agent in cross projects in classic release pipeline
            - DeploymentAgent. Classic way in Deployment. Use as deploy agent in one project in classic click in UI release pipeline

            There are two different pool types: Automation (Agent pools) and Deployment (Deployment pools)
         .EXAMPLE
            Install-VstsAgentWin
         .EXAMPLE
            $pwd = ConvertTo-SecureString "MyPassword" -AsPlainText -Force
            Install-VstsAgentWin -EnvironmentName Test1 -WindowsLogonAccount "nameofuser@sek.se" -WindowsLogonPassword $pwd
         .EXAMPLE
            Install-VstsAgentWin -Pool ConfigurationManagement -CapabilityTags db-server=devsql.sek.se,GDPR
         .EXAMPLE
            $cred = Get-Credential -UserName $env:USERNAME@$env:USERDNSDOMAIN
            Install-VstsAgentWin -Auth negotiate -Credential $cred
         .EXAMPLE
            Install-VstsAgentWin -EnvironmentName DevTechIT -EnvironmentVMResourceTags hero,kite -WindowsLogonAccount "NT AUTHORITY\SYSTEM"
         .EXAMPLE
            Install-VstsAgentWin -DeploymentPoolName SEK-SIP
         .EXAMPLE
            Install-VstsAgentWin -DeploymentGroupName MX-MXServers -ProjectName Infra -DeploymentGroupTags Web,App
         .EXAMPLE
            "E:/azagent/A2" | Install-VstsAgentWin -DeploymentPoolName MyPool -SkipNewPackage
         .LINK
            https://github.com/microsoft/azure-pipelines-agent/blob/master/src/Test/L0/Listener/Configuration/ConfigurationManagerL0.cs
         .LINK
            https://github.com/microsoft/azure-pipelines-agent/blob/master/src/Agent.Listener/Configuration/ConfigurationManager.cs#L185
         .LINK
            https://github.com/microsoft/azure-pipelines-agent/blob/master/src/Microsoft.VisualStudio.Services.Agent/Constants.cs#L80
         .OUTPUTS
            [System.Management.Automation.PathInfo] Path to agent folder
     #>
   [CmdletBinding(DefaultParameterSetName = "Automation")]
   param (
      # Authentication type: personal access token (pat), windows default credentials (integrated) or PSCredential
      # If using pat you MUST specified your pat-token in varable $env:VSTS_AGENT_INPUT_token before you call.
      # Note:
      # Create a personal access token with name 'VstsAgent' for 'All accessible organizations' with Scopes:
      # Agent Pools (Read & mangage); Environment (Read & manage); Deployment Groups (Read & manage) 
      [ValidateSet("pat", "integrated", "negotiate")]
      [String] $Auth = "integrated",

      # Use when auth is negotiate
      [PSCredential] $Credential,

      # Pool name under Agent pools. Use as automation agent in yaml file as keyword pool
      [Parameter(ParameterSetName = "Automation")]
      [String] $Pool,

      # Environment name under Environments in your project. Use as deploy agent in release yaml file as keyword environment
      [Parameter(Mandatory, ParameterSetName = "Environment")]
      [String] $EnvironmentName,

      # List of custom tags using for this enviroment resource 
      [Parameter(ParameterSetName = "Environment")]
      [String[]] $EnvironmentVMResourceTags,

      # Pool name under Deployment pools. Use as deploy agent a cross projects in classic release pipeline
      [Parameter(Mandatory, ParameterSetName = "SharedDeploymentGroup")]
      [String] $DeploymentPoolName,

      # Group name under Deployment groups in your project. Use as deploy agent in one project in classic release pipeline
      [Parameter(Mandatory, ParameterSetName = "DeploymentGroup")]
      [String] $DeploymentGroupName,

      # List of custom tags using for this target deployment group
      [Parameter(ParameterSetName = "DeploymentGroup")]
      [String[]] $DeploymentGroupTags,
      
      # Project name under the collection
      [Parameter(ParameterSetName = "Environment")]
      [Parameter(ParameterSetName = "DeploymentGroup")]
      [String] $ProjectName = "SEK",

      # Add User-defined capabilities to this automation agent
      # Ex -CapabilityTags db-server=devsql.sek.se, SocSafe
      [String[]] $CapabilityTags,
      
      # Agent run as Windows service username
      [String] $WindowsLogonAccount = $VstsAgentWinWindowsLogonAccount,

      # Agent run as Windows service password
      [SecureString] $WindowsLogonPassword = (New-Object -TypeName "SecureString"),

      # Use this flag when you already have an agent unziped in the folder
      [Switch] $SkipNewPackage,

      # Use this flag if you will install from internet, default using Azure DevOps feed
      [Switch] $OnlineInstallation,

      # Path to agent home folder. If folder MUST exist
      [Parameter(ValueFromPipeline)]
      [ValidateScript( { Test-Path $_ })]
      [String] $AgentPath
   )
   begin {
      if ($Auth -eq "pat" -and $null -eq $env:VSTS_AGENT_INPUT_token) {
         throw "You must specified your pat-token in varable `$env:VSTS_AGENT_INPUT_token before you call"
      }
      if ($Auth -eq "negotiate" -and $null -eq $Credential) {
         throw "You must specified -Credential before you call"
      }
      if (-not($WindowsLogonAccount.ToUpper().Contains("AUTHORITY")) -and $WindowsLogonPassword.Length -eq 0) {
         throw "You must specified WindowsLogonPassword as SecureString"
      }
   }
   process {
      if (-not (Test-RunAsAdmin)) {
         throw "You MUST run this functions as Administrator"
      }
      if ($AgentPath) {
         $AgentPath = Resolve-Path $AgentPath # Braces and belt. Fix to absolut path
         if ((Get-Item $AgentPath).BaseName -match "^A(\d+)$") {
            $AgentLocationId = $Matches[1]
         }
      }
      else {
         # Create location folder
         $AgentBasePath = Get-AgentBasePath
         $AgentLocationId = 1..10 | Where-Object { -not (Test-Path (Join-Path $AgentBasePath "A$_")) } | Select-Object -First 1
         if ($AgentLocationId) {
            $AgentPath = New-Item $AgentBasePath/A$AgentLocationId -ItemType Directory
         }
         else {
            throw "Avoid using more than 10 agents on the same machine"
         }
      }
      
      if (-not ($SkipNewPackage)) {
         $Package = @{
            AgentBasePath      = $AgentBasePath
            AgentPath          = $AgentPath
            OnlineInstallation = $OnlineInstallation
         }
         Save-VstsAgentPackage @Package
      }

      if (-not (Test-Path $AgentPath/config.cmd)) {
         throw "File $AgentPath/config.cmd is missing"
      }

      # Add capabilities if needed
      if ($CapabilityTags) {
         $CapabilitiesFile = New-Item -Path $AgentPath -Name .capabilities -ItemType File
         $CapabilityTags | ForEach-Object {
            if ($_.Contains("=")) {
               Add-Content -Path $CapabilitiesFile -Value $_
            }
            else {
               Add-Content -Path $CapabilitiesFile -Value "$_="
            }
         }
      }

      # Set arguments
      [String[]]$ConfigureArgs = "--unattended"
      $ConfigureArgs += "--url '$VstsAgentWinHostUrl'"
      $ConfigureArgs += "--auth '$Auth'"
      $ConfigureArgs += "--windowslogonaccount '$WindowsLogonAccount'"
      $ConfigureArgs += "--runAsService"

      if ($Auth -eq "negotiate") {
         [System.Net.NetworkCredential] $NetworkCredential = New-Object -TypeName System.Net.NetworkCredential -ArgumentList $Credential.UserName, $Credential.Password
         $env:VSTS_AGENT_INPUT_userName = $NetworkCredential.UserName
         $env:VSTS_AGENT_INPUT_password = $NetworkCredential.Password
      }

      if ($AgentLocationId) {
         $ConfigureArgs += "--agent '$env:COMPUTERNAME-$AgentLocationId'"
      }

      if ($Pool) {
         $ConfigureArgs += "--pool '$Pool'"
      }

      if ($EnvironmentName) {
         $ConfigureArgs += "--collectionname '$VstsAgentWinCollectionName'"
         $ConfigureArgs += "--projectname '$ProjectName'"
         $ConfigureArgs += "--environment"
         $ConfigureArgs += "--environmentname '$EnvironmentName'"
      }

      if ($EnvironmentVMResourceTags) {
         $ConfigureArgs += "--addvirtualmachineresourcetags"
         $ConfigureArgs += "--virtualmachineresourcetags '" + ($EnvironmentVMResourceTags -join ",") + "'"
      }

      if ($DeploymentPoolName) {
         $ConfigureArgs += "--deploymentpool"
         $ConfigureArgs += "--deploymentpoolname '$DeploymentPoolName'"
      }

      if ($DeploymentGroupName) {
         $ConfigureArgs += "--collectionname '$VstsAgentWinCollectionName'"
         $ConfigureArgs += "--projectname '$ProjectName'"
         $ConfigureArgs += "--deploymentgroup"
         $ConfigureArgs += "--deploymentgroupname '$DeploymentGroupName'"
      }
      
      if ($DeploymentGroupTags) {
         $ConfigureArgs += "--adddeploymentgrouptags"
         $ConfigureArgs += "--deploymentgrouptags '" + ($DeploymentGroupTags -join ",") + "'"
      }

      if ($WindowsLogonPassword.Length -gt 0) {
         [System.Net.NetworkCredential] $NetworkCredential = New-Object -TypeName System.Net.NetworkCredential -ArgumentList "", $WindowsLogonPassword
         $env:VSTS_AGENT_INPUT_windowslogonpassword = $NetworkCredential.Password
      }

      Import-AzDoCertificates # Install cert into Windows Certificate Manager

      # Linux background application (Git) and technologies (Node.js) won't check the Windows Certificate Manager,
      # they just expect all certificates are just a file on disk.
      $CertsPath = New-Item -Path $AgentPath -Name ca.pem -ItemType File -Force
      Get-SslCACertsContent | Set-Content -Path $CertsPath
      $ConfigureArgs += "--sslcacert '$CertsPath'"

      # Run agent config
      $status = Invoke-VstsAgentConfig -AgentPath $AgentPath -ConfigureArgs $ConfigureArgs
      $env:VSTS_AGENT_INPUT_windowslogonpassword = $null

      if (-not ($status)) {
         throw "The installation failed"
      }

      Write-Host "The installation was successful :-)"
      return [PSCustomObject] @{
         AgentPath                = $AgentPath
         ServiceAccountCredential = New-Object -TypeName PSCredential -ArgumentList $WindowsLogonAccount, $WindowsLogonPassword
      }
   }
}
