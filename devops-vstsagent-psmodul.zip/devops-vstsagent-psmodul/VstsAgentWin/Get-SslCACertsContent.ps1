function Get-SslCACertsContent {
   <#
         .Synopsis
            Get self-signed root ca certificate and intermediate ca certificate content
         .DESCRIPTION
            Get self-signed root ca certificate and intermediate ca certificate content
         .EXAMPLE
            Get-SslCACertsContent | Set-Content ca.pem
         .INPUTS
            No input
         .OUTPUTS
            Content of root ca and issuing content
     #>
   [CmdletBinding()]
   param ()
   process {
      foreach ($FilePath in (Get-ChildItem $PSScriptRoot\certificate | Convert-Path)) {
         $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2 $FilePath
         $chain = New-Object System.Security.Cryptography.X509Certificates.X509Chain
         $chain.build($cert) | Out-Null
        
         if ($chain.ChainElements.Count -eq 1) {
            $root = Get-Content $FilePath
         }

         if ($chain.ChainElements.Count -gt 1) {
            $intermediate += Get-Content $FilePath
         }
      }

      if (-not($root)) {
         throw "Missing self-signed root ca certificate into folder $PSScriptRoot\certificate"
      }

      if (-not($intermediate)) {
         throw "Missing self-signed intermediate ca certificate(s) into folder $PSScriptRoot\certificate"
      }
      
      return $root + $intermediate
   }
}