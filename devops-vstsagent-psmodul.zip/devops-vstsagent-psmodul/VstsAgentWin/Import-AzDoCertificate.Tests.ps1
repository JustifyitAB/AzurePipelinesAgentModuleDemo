BeforeAll {
    . $PSScriptRoot\Import-AzDoCertificates.ps1
    Mock Test-RunAsAdmin { $true }
    Mock Import-Certificate {
        param(
            $FilePath,
            $CertStoreLocation
        )
        $script:FilePath = $FilePath
        $script:CertStoreLocation = $CertStoreLocation
    }
}

Describe "Import-AzDoCertificate" {
    BeforeAll {
        $script:FilePath = $null,
        $script:CertStoreLocation = $null
    }

    It "Should return CA" {
        Mock Get-ChildItem { Convert-Path "$PSScriptRoot\certificate\SEK-Issuing-CA-v3.cer" } -ParameterFilter { $Path -like '*certificate*' }
        Mock Get-ChildItem {} -ParameterFilter { $Path -like 'Cert:*' }

        Import-AzDoCertificates
        
        $script:FilePath | Should -BeLike '*SEK-Issuing-CA-v3.cer*'
        $script:CertStoreLocation | Should -Be 'Cert:\LocalMachine\CA'
    }

    It "Should return Root" {
        Mock Get-ChildItem { Convert-Path "$PSScriptRoot\certificate\SEK-Root-CA-v3.cer" } -ParameterFilter { $Path -like '*certificate*' }
        Mock Get-ChildItem {} -ParameterFilter { $Path -like 'Cert:*' }

        Import-AzDoCertificates
        
        $script:FilePath | Should -BeLike '*SEK-Root-CA-v3.cer*'
        $script:CertStoreLocation | Should -Be 'Cert:\LocalMachine\Root'
    }
}
