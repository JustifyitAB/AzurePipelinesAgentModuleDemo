BeforeAll {
    . $PSScriptRoot\Get-SslCACertsContent.ps1
}

Describe "Get-SslCACertsContent" {

    It "Should return CA and Issuing content" {
        Get-SslCACertsContent | Where-Object { $_ -like "*BEGIN CERTIFICATE*" } | Should -HaveCount 2
    }
}
