function ConvertTo-MarkdownHelpTable {
    [CmdletBinding()]
    param (
        [Parameter(ValueFromPipeline)]
        [ValidateScript( { Test-Path $_ })]
        $Path
    )
    begin {
        $Table = @("| Name | Synopsis |")
        $Table += "| - | - |"
    }
    process {
        $Name = $Path.Name -replace $Path.Extension, ""
        $RelativePath = Join-Path -Path $Path.Directory.Name -ChildPath $Path.Name
        $Synopsis = (Get-Content $Path | Select-String "## SYNOPSIS" -Context 0, 1).Context.PostContext
        $Table += "| [$Name]($RelativePath) | $Synopsis |"
    }
    end {
        return $Table
    }
}

function Set-MarkdownHelpTable {
    [CmdletBinding()]
    param (
        [String[]] $Table,

        [ValidateScript( { Test-Path $_ })]
        [String] $MarkdownFile,

        [String] $Head = "## Commands"
    )
    process {
        $Content = Get-Content $MarkdownFile
        $StartLine = ($Content | Select-String $Head).LineNumber
        $NewContent = $Content[0..$StartLine]
        $NewContent += $Table
        $EndLine = ($Content | Select-String "#" | Where-Object LineNumber -gt $StartLine | Select-Object -First 1).LineNumber
        if ($EndLine) {
            $NewContent += @("")
            $NewContent += $Content[($EndLine - 1)..($Content.Length - 1)]
        }
        Set-Content -Path $MarkdownFile -Value $NewContent
    }
}

if (-not (Get-Module -ListAvailable | Where-Object Name -eq platyPS)) {
    Install-Module -Name platyPS
}

# Import latest module local
Import-Module -Name $PSScriptRoot\VstsAgentWin -Scope Local -Force

# Delete docs folder
if (Test-Path $PSScriptRoot\docs) {
    Remove-Item $PSScriptRoot\docs -Recurse
}

# Generate new docs
New-MarkdownHelp -Module VstsAgentWin -OutputFolder $PSScriptRoot\docs -Force

# Update table in README file
$Table = Get-ChildItem $PSScriptRoot\docs | ConvertTo-MarkdownHelpTable
Set-MarkdownHelpTable -Table $Table -MarkdownFile $PSScriptRoot\README.md
